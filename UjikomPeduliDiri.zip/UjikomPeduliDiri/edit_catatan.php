 <div class="card">
	<div class="card-header">
		 <a href="user.php" class="btn btn-primary btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fa fa-arrow-left"></i>
                                        </span>
                                        <span class="text">Kembali</span>
                                    </a>

</div>
<div class="card-body">
	<?php
	$data = file('catatan.txt',FILE_IGNORE_NEW_LINES);
	$id_catatan = $_GET['id_catatan'];
	foreach ($data as $value) {
		$pecah = explode('|',$value);
		if($pecah['0']==$id_catatan){
			?>


	<form action="simpan_edit_catatan.php" method="post">
		<input type="hidden" name="id_catatan" value="<?=$pecah['0']; ?> ">
		<div class="card-body">
		<div class="form-group row">
			<label class="col-sm-2 col-form-label"> Pilih Tanggal </label>
			<div class="col-sm-3"> 
			 <input value="<?=$pecah ['3'] ?>"  type="date" name="tanggal" id="txtDate" min=<?php echo date("Y-m-d");?> " required class="form-control placeholder="Masukkan Tanggal">
			</div>
		</div>
				<div class="form-group row"> 
					<label class="col-sm-2 col-form-label"> Pilih Jam </label>
					<div class="col-sm-3">

						<input value="<?=$pecah ['4'] ?>" type="time" name="jam" class ="form-control" placeholder="Masukkan Jam">
				</div>
			</div>
				<div class="form-group row"> 
					<label class="col-sm-2 col-form-label"> Pilih Lokasi</label> 
					<div class ="col-sm-3">
						<input value="<?=$pecah ['5'] ?>" type="text" name="lokasi" class="form-control" placeholder="Masukkan Lokasi">
				</div>
			</div>
				<div class="form-group row"> 
					<label class="col-sm-2 col-form-label"> Suhu Tubuh</label>
					<div class="col-sm-3">
				<input value="<?=$pecah ['6'] ?>" name ="suhu" type="text" required class ="form-control" placeholder="Masukkan Suhu Tubuh">
				</div>
			</div>
					<div class="form-group"> 
						<button type="submit" class="btn btn-primary"><i class ="fa fa-save"></i>SIMPAN</button>
						<button type="reset" class="btn btn-warning"><i class ="fa fa-trash"></i>KOSONGKAN</button>
	</div> 
</form>
<?php } }  ?>
</div>
</div>